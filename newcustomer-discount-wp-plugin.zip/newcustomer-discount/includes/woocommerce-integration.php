<?php
/**
 * WooCommerce Integration
 *
 * @package NewCustomerDiscount
 */

if (!defined('ABSPATH')) {
    exit;
}

// WooCommerce spezifische Hooks hier